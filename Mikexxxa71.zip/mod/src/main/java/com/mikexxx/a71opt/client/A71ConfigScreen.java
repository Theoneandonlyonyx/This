package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Einstellungen der Mod direkt im Spiel. Erreichbar ueber das Mods-Menue (Config),
 * den Knopf "A71" im Pausenmenue und den Befehl /a71 config.
 * Aenderungen gelten sofort und werden beim Schliessen gespeichert.
 */
public class A71ConfigScreen extends Screen {

    private final Screen parent;

    public A71ConfigScreen(Screen parent) {
        super(Component.literal("A71 Optimizer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int gap = 8;
        int colW = Math.min(150, (this.width - 3 * gap) / 2);
        int leftX = this.width / 2 - gap / 2 - colW;
        int rightX = this.width / 2 + gap / 2;
        int top = 32;
        int step = 24;

        addToggle(leftX, top, colW, "Mod aktiv", A71Config.ENABLED);
        addToggle(leftX, top + step, colW, "HUD", A71Config.SHOW_HUD);
        addToggle(leftX, top + step * 2, colW, "Auto-Renderdistanz", A71Config.ADAPTIVE);
        addToggle(leftX, top + step * 3, colW, "Notbremse", A71Config.EMERGENCY);
        addToggle(leftX, top + step * 4, colW, "Notbremse-Shader aus", A71Config.EMERGENCY_SHADERS_OFF);

        addStepper(rightX, top, colW, "Ziel-FPS", A71Config.TARGET_FPS, 10, 120, 5);
        addStepper(rightX, top + step, colW, "Max. RD", A71Config.MAX_RENDER_DISTANCE, 2, 32, 1);
        addToggle(rightX, top + step * 2, colW, "Spawn-Chunks klein", A71Config.SHRINK_SPAWN_CHUNKS);
        addToggle(rightX, top + step * 3, colW, "Chat-Hinweise", A71Config.CHAT_HINTS);
        this.addRenderableWidget(Button.builder(Component.literal("Profil neu anwenden"),
                        b -> Governor.reapplyProfile(Minecraft.getInstance()))
                .bounds(rightX, top + step * 4, colW, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Fertig"), b -> this.onClose())
                .bounds(this.width / 2 - 75, top + step * 5 + 6, 150, 20).build());
    }

    private void addToggle(int x, int y, int w, String label, ForgeConfigSpec.BooleanValue value) {
        this.addRenderableWidget(Button.builder(toggleText(label, value.get()), b -> {
            A71Config.setBool(value, !value.get());
            b.setMessage(toggleText(label, value.get()));
        }).bounds(x, y, w, 20).build());
    }

    private static Component toggleText(String label, boolean on) {
        return Component.literal(label + ": " + (on ? "AN" : "AUS"));
    }

    private void addStepper(int x, int y, int w, String label, ForgeConfigSpec.IntValue value,
                            int min, int max, int step) {
        Button center = Button.builder(Component.literal(label + ": " + value.get()), b -> {
        }).bounds(x + 22, y, w - 44, 20).build();
        center.active = false;

        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            A71Config.setInt(value, Math.max(min, value.get() - step));
            center.setMessage(Component.literal(label + ": " + value.get()));
        }).bounds(x, y, 20, 20).build());
        this.addRenderableWidget(center);
        this.addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            A71Config.setInt(value, Math.min(max, value.get() + step));
            center.setMessage(Component.literal(label + ": " + value.get()));
        }).bounds(x + w - 20, y, 20, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, Component.literal("Aenderungen gelten sofort und werden gespeichert."),
                this.width / 2, 32 + 24 * 5 + 32, 0xAAAAAA);
    }

    @Override
    public void onClose() {
        A71Config.save();
        Minecraft mc = Minecraft.getInstance();
        Governor.reloadFromConfig(mc);
        mc.setScreen(this.parent);
    }
}
