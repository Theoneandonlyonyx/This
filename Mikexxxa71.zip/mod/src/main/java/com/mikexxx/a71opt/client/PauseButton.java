package com.mikexxx.a71opt.client;

import com.mikexxx.a71opt.A71Optimizer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Kleiner Knopf "A71" oben links im Pausenmenue. Praktisch am Handy, weil man keinen Befehl tippen muss.
 */
@Mod.EventBusSubscriber(modid = A71Optimizer.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PauseButton {

    private PauseButton() {
    }

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        if (!(screen instanceof PauseScreen)) {
            return;
        }
        event.addListener(Button.builder(Component.literal("A71"),
                        b -> Minecraft.getInstance().setScreen(new A71ConfigScreen(screen)))
                .bounds(4, 4, 40, 20).build());
    }
}
