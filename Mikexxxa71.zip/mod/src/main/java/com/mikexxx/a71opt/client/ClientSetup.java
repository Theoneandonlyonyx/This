package com.mikexxx.a71opt.client;

import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.fml.ModLoadingContext;

/**
 * Wird nur auf dem Client aufgerufen (eigene Klasse, damit Client-Klassen auf einem Server nie geladen werden).
 * Macht den "Config"-Knopf im Mods-Menue verfuegbar.
 */
public final class ClientSetup {

    private ClientSetup() {
    }

    public static void register() {
        ModLoadingContext.get().registerExtensionPoint(
                ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory((minecraft, parent) -> new A71ConfigScreen(parent)));
    }
}
