package com.mikexxx.a71opt;

import com.mikexxx.a71opt.client.ClientSetup;
import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

/**
 * Mikexxx A71 Optimizer - reine Client-Mod fuer Forge 1.20.1.
 * Die eigentliche Arbeit steckt in den Klassen im Paket "client".
 */
@Mod(A71Optimizer.MODID)
public class A71Optimizer {

    public static final String MODID = "mikexxx_a71opt";
    public static final Logger LOGGER = LogUtils.getLogger();

    public A71Optimizer() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, A71Config.SPEC);
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.register();
        }
        LOGGER.info("[A71] Mikexxx A71 Optimizer geladen");
    }
}
